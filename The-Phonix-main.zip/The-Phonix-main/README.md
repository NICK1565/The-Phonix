#The idea and background:
The Phoenix is a mythological bird existing in the habits and traditions of ancient people able to control fire and live again from its own ashes.
The comparison is regarded to actual time in which pandemic is impacting seriously various aspect of human life and a number of business sectors, accordingly!
#Data:
One of these fields is the general aviation in which many airlines are suffering dramatically.
Before pandemic, in 2019, passengers that flew domestically and internationally were around 4 bilion worldwide!
This was a record data as this figure is  representing about the half of the entire popolation of Earth: a spectacular outcome at that time, indeed!
Pandemic is still impacting seriously on this industry so far.
#AI techniques:
When this dramatic situation will be over there will be many challenges ahead to face because the complete pipeline of economic activities will be affected,
such as tourism and travel, hospitality, mobiliity. All mentioned related activities will boom again in total safety, whenever an important point of view will be generally assumed:
overall safety and good welfare of global population must reinstated again.
At this stage one must be ready to face the new normal accordingly. Many jobs have been lost and many others willin the near future on one hand but, as a consequence, many others will spring out anew. In this context AI will ease effectively to achieve this goal. Digitization will increase in all sectors and major improvements in all activities related to air transportation  will perform.  For instance let's think of security control, passport control, facial control at the custom in certain airports where passengers will be flying from.
#Challenges ahead: 
Improving air traffic by considering also ecological impact on our  Earth and managing correctly the so called Environmental Sustainability.
Again here is the concept of the Phoenix: livING  again longer and better!
#What next: 
Future generations will have to face bigger troubles if some crucial knots are not solved as soon as possible!
#Acknowledgements:
Airline and tourism leading players consulted personally along with Trade Newspapers, job relation, case histories, conferences, studies etc.#
